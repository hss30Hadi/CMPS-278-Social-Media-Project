// delete button
document.querySelector('.delete-account-button').addEventListener('click', () => {
  const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

  if (!userId) {
    alert('User not logged in. Cannot delete account.');
    return;
  }

  const confirmation = confirm('Are you sure you want to delete your account? This action cannot be undone.');
  if (!confirmation) return;

  fetch(`http://localhost:3000/delete-account/${userId}`, {
    method: 'DELETE',
  })
    .then((response) => {
      if (response.ok) {
        alert('Account deleted successfully. You will be logged out.');
        localStorage.removeItem('userId'); // Clear user session
        window.location.href = '../../login_sign up/login.html'; // Redirect to login page
      } else {
        return response.json().then((data) => {
          alert(`Failed to delete account: ${data.message}`);
        });
      }
    })
    .catch((error) => {
      console.error('Error deleting account:', error);
      alert('An error occurred while deleting the account.');
    });
});



function openEditModal() {
  document.getElementById("editProfileModal").style.display = "block";
}

function closeEditModal() {
  document.getElementById("editProfileModal").style.display = "none";
}

async function saveProfile() {
  const bio = document.getElementById('editBio').value;
  const profilePicInput = document.getElementById('editProfilePic');
  const formData = new FormData();
  const userId = localStorage.getItem('userId'); // Add userId to the request

  formData.append('bio', bio);
  formData.append('userId', userId);

  if (profilePicInput.files[0]) {
    formData.append('profilePic', profilePicInput.files[0]);
  }

  try {
    const response = await fetch('http://localhost:3000/update-profile', {
      method: 'POST',
      body: formData,
    });

    if (response.ok) {
      const result = await response.json();
      document.getElementById('bio').textContent = result.bio;

      // Update the profile picture in the DOM
      if (result.profilePic) {
        document.getElementById('profilePic').src = `../../profilePics/${result.profilePic}`;
      }

      closeEditModal();
    } else {
      console.error('Failed to update profile');
    }
  } catch (error) {
    console.error('Error updating profile:', error);
  }
}



// Fetch user profile details (bio and profile picture)
async function fetchUserProfile() {
  const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

  try {
    const response = await fetch(`/user-profile/${userId}`);
    if (response.ok) {
      const user = await response.json();
      document.getElementById('username').textContent = user.username || Username;
      document.getElementById('bio').textContent = user.bio || 'This is your bio';
      document.getElementById('profilePic').src = 
      user.profile_pic === '/default-profile-pic.jpg' 
        ? 'profile-pic.jpg' 
        : `../../profilePics/${user.profile_pic}`;
    
        
    } else {
      console.error('Failed to fetch user profile');
    }
  } catch (error) {
    console.error('Error fetching user profile:', error);
  }
}

// Function to fetch posts for the user
function fetchUserPosts() {
  const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

  if (!userId) {
    console.error('User not logged in or invalid userId');
    return;
  }

  fetch(`/user-posts/${userId}`)
    .then(response => response.json())
    .then(posts => {
      const postsContainer = document.querySelector('.posts-section');
      postsContainer.innerHTML = ''; // Clear any previous posts

      if (posts.length === 0) {
        postsContainer.innerHTML = '<p>No posts yet.</p>';
      } else {
        posts.forEach(post => {
          const postElement = document.createElement('div');
          postElement.classList.add('post');


          const formattedTimestamp = new Date(post.created_at).toLocaleString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
          });

          postElement.innerHTML = `
            <div class="centered-container">
              <div class="post-container">
                <div class="post-image">
                  ${post.image_url ? `<img id="postImage" src="../../${post.image_url}" alt="Post Image" class="post-image" />` : ''}
                </div>
                <div class="post-actions">
                  <button id="thumbUp" class="thumb-up">👍 <span class="like-count">${post.likes || 0}</span></button>
                  <button id="thumbDown" class="thumb-down">👎 <span class="dislike-count">${post.dislikes || 0}</span></button>
                  <button id="commentButton" class="comment-button">💬</button>
                </div>
                <p id="description">${post.post_text}</p>
                
                <div class="comments-section" id="comments-${post.post_id}" style="display: none;"></div>
                <div class="post-timestamp">
                  <span>${formattedTimestamp}</span>
                </div>
              </div>
            </div>
          `;
          postsContainer.appendChild(postElement);

          // Add event listener for the comment button
          const commentBtn = postElement.querySelector('#commentButton');
          const commentsSection = postElement.querySelector(`#comments-${post.post_id}`);

          commentBtn.addEventListener('click', () => {
            fetch(`/post/${post.post_id}/comments`)
              .then(response => response.json())
              .then(comments => {
                commentsSection.innerHTML = comments.map(comment => {
                  const commentLikes = comment.likes;
                  const commentDislikes = comment.dislikes;

                  return `
                    <div class="comment">
                      <div class="comment-header">
                        <img src="${comment.profile_pic === '/default-profile-pic.jpg' 
                          ? '../../profilePics/default-profile.jpg' 
                          : `../../profilePics/${comment.profile_pic}`}" 
                          alt="${comment.username}" 
                          class="comment-profile-pic" />
                        <span class="comment-username">${comment.username}</span>
                      </div>
                      <div class="comment-text">${comment.comment_text}</div>
                      <div class="comment-footer">
                        <span class="reaction">
                          👍 <span class="like-count">${commentLikes}</span>
                          👎 <span class="dislike-count">${commentDislikes}</span>
                        </span>
                      </div>
                    </div>
                  `;
                }).join('');
                commentsSection.style.display = 'block'; // Show the comments section
              })
              .catch(error => console.error('Error fetching comments:', error));
          });
        });
      }
    })
    .catch(error => {
      console.error('Error fetching posts:', error);
    });
}




async function fetchProfileStats() {
  const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

  if (!userId) {
    console.error('User not logged in or invalid userId');
    return;
  }

  try {
    // Fetch posts count
    const postsResponse = await fetch(`http://localhost:3000/user-posts-count/${userId}`);
    const postsData = await postsResponse.json();
    document.getElementById('nbPosts').textContent = postsData.nbPosts || 0;

    // Fetch friends count
    const friendsResponse = await fetch(`http://localhost:3000/user-friends-count/${userId}`);
    const friendsData = await friendsResponse.json();
    document.getElementById('nbFriends').textContent = friendsData.nbFriends || 0;

  } catch (error) {
    console.error('Error fetching profile stats:', error);
  }
}

// Call the function when the page loads
document.addEventListener('DOMContentLoaded', fetchProfileStats);


// Call the functions when the page loads
document.addEventListener('DOMContentLoaded', () => {
  fetchUserProfile(); // Fetch user profile data
  fetchUserPosts();   // Fetch user posts
});
