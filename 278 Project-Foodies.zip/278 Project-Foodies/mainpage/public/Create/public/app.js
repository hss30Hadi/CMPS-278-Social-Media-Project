const express = require('express');
const multer = require('multer');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');

const app = express();
const port = 3000;

// Configure CORS to allow frontend requests
app.use(cors());

// MySQL Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'myappdb',
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    process.exit(1); // Exit if the database connection fails
  }
  console.log('Connected to MySQL Database');
});

// Multer configuration for file uploads
const upload = multer({
  dest: 'uploads/', // Temporary storage for uploaded files
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB size limit
});

// Serve static files from the uploads directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Middleware to parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create post endpoint
app.post('/create-post', upload.single('file'), (req, res) => {
  try {
    const userId = req.body.userId; // Replace with actual user ID from authentication
    const { description, visibility } = req.body;
    const file = req.file;

    // Check for missing fields
    if (!description || !visibility || !file) {
      console.error('Missing required fields:', { description, visibility, file });
      return res.status(400).json({ message: 'All fields are required.' });
    }

    // Construct the image URL
    const imageUrl = `/uploads/${file.filename}`;

    // Insert the post into the database
    const query = `
      INSERT INTO Posts (user_id, post_text, image_url, visibility)
      VALUES (?, ?, ?, ?)
    `;
    db.query(query, [userId, description, imageUrl, visibility], (err, result) => {
      if (err) {
        console.error('Database error:', err);
        return res.status(500).json({ message: 'Database error.' });
      }

      // Respond with a success message
      res.status(200).json({ message: 'Post created successfully!' });
    });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
