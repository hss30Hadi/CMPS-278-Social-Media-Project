document.getElementById('postForm').addEventListener('submit', async (e) => {
  e.preventDefault(); // Prevent the default form submission behavior

  const formData = new FormData(e.target); // Collect form data

  // Get the user ID from local storage
  const userId = localStorage.getItem("userId");

  // Add the user ID to the form data
  formData.append("userId", userId);

  try {
    const response = await fetch('http://localhost:3000/create-post', {
      method: 'POST',
      body: formData, // Send form data as the request body
    });
  
      // Capture the server response as text for debugging
      const result = await response.text();
      console.log('Server Response:', result);
  
      if (!response.ok) {
        throw new Error(result); // Throw an error if the response isn't ok
      }
  
      window.location.href = '../../Profile/profilePage.html';

    } catch (err) {
      console.error('Error:', err);
      alert('Something went wrong. Please try again.');
    }
  });
  