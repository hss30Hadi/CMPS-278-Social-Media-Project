document.addEventListener("DOMContentLoaded", () => {
    const resetForm = document.getElementById('reset-password-form');
  
    resetForm.addEventListener('submit', async (e) => {
      e.preventDefault();
  
      const email = document.getElementById('email').value;
      const newPassword = document.getElementById('new-password').value;
      const confirmPassword = document.getElementById('confirm-password').value;
  
      if (newPassword !== confirmPassword) {
        alert("Passwords do not match.");
        return;
      }
  
      // Request a verification code if not already generated
      try {
        const response = await fetch('/request-reset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        const result = await response.json();
  
        if (response.ok) {
          alert(result.message);
  
          // Prompt for verification code directly from the user
          const verificationCode = prompt("Enter the verification code sent to your email:");
  
          // Send the reset password request
          const resetResponse = await fetch('/reset-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, token: verificationCode, newPassword })
          });
  
          const resetResult = await resetResponse.json();
          if (resetResponse.ok) {
            alert(resetResult.message);
            window.location.href = '../login_sign up/login.html';
          } else {
            alert(resetResult.message || 'Failed to reset password');
          }
        } else {
          alert(result.message || 'Failed to send verification code');
        }
      } catch (error) {
        console.error('Error during reset process:', error);
        alert('Error during reset process');
      }
    });
  });
  