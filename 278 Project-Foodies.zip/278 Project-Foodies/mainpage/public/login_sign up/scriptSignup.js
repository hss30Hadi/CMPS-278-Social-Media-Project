
  
document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault(); // Prevent the form from reloading the page
        // Get form values
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    // Send POST request to the backend for signup
    try {
      const response = await fetch('/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password })
      });
  
      const result = await response.json();
      if (response.ok) {
        alert(result.message); // Show success message
        localStorage.setItem('email', email); // Save email for use during verification
        window.location.href = 'verification.html'; // Redirect to verification page

      } else {
        alert(result.message || 'Signup failed');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred during signup');
    }
  });
