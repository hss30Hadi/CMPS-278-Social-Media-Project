
document.getElementById('verify-button').addEventListener('click', async (e) => {
    e.preventDefault();
  
    const verificationCode = document.getElementById('verification-code').value;
    const email = localStorage.getItem('email'); // Retrieve email from localStorage
  
    // Send the verification code and email to the backend
    try {
      const response = await fetch('/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, verificationCode })
      });
  
      const result = await response.json();
      if (response.ok) {
        alert(result.message); // Show success message
        // Redirect to login page after successful verification
        window.location.href = 'login.html';
      } else {
        alert(result.message || 'Verification failed');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred during verification');
    }
  });
