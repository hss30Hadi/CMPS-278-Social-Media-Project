document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    // Get form values
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
  
    try {
      // Send login request
      const response = await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });
  
      const result = await response.json();
      if (response.ok) {
        localStorage.setItem('userId', result.user.id);

        // Redirect or perform other actions upon successful login
        window.location.href = '../Feed/feed.html'; // example redirection
      } else if (result.redirectTo) {
        alert(result.message); // Notify the user to verify
        window.location.href = result.redirectTo; // Redirect to verification page
      }else {
        document.getElementById('login-message').innerText = result.message || 'Login failed';
      }
    } catch (error) {
      console.error('Error:', error);
      document.getElementById('login-message').innerText = 'An error occurred during login';
    }
  });