function sendMessage(event) {
    event.preventDefault();

    const userId = localStorage.getItem('userId'); 
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    const room = localStorage.getItem('currentRoom'); 

    if (!userId) {
        console.error('User ID not found in localStorage. User must be logged in.');
        return;
    }

    if (!message) {
        console.error('Message is empty. Please type something before sending.');
        return;
    }

    console.log('Sending message:', { room, sender: userId, message }); // Debug log

    // Send the message to the backend
    fetch('/api/chat/sendMessage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room, sender: userId, message }),
    })
        .then((response) => {
            console.log('API Response Status:', response.status);
            return response.json();
        })
        .then((data) => {
            if (data.success) {
                console.log('Message sent successfully');
                input.value = ''; // Clear input
                fetchMessages(); // Refresh messages
            } else {
                console.error('Message failed to send:', data.error || 'Unknown error');
            }
        })
        .catch((error) => console.error('Error sending message:', error));
}

function fetchFriends() {
    const userId = parseInt(localStorage.getItem('userId'), 10); // Get logged-in user's ID
    if (!userId) {
        console.error('User ID not found in localStorage.');
        return;
    }

    fetch(`/api/friends/${userId}`)
        .then((response) => response.json())
        .then((friends) => {
            const friendsListContainer = document.querySelector('.friend-list');
            friendsListContainer.innerHTML = ''; // Clear existing friends

            friends.forEach((friend) => {
                const friendElement = document.createElement('div');
                friendElement.classList.add('friend');
                
                friendElement.innerHTML = `
                    <img src="${friend.profile_pic === '/default-profile-pic.jpg' 
                        ? '../../resources/default-profile.jpg' 
                        : `../../profilePics/${friend.profile_pic}`}" 
                        alt="${friend.username}"    
                        class="friend-pic" />
                    <div>
                        <p class="friend-name">${friend.username}</p>
                    </div>
                `;

                // Add event listener to handle active state
                friendElement.addEventListener('click', () => {
                    // Remove "active" class from all friends
                    document.querySelectorAll('.friend').forEach((el) => el.classList.remove('active'));

                    // Add "active" class to the clicked friend
                    friendElement.classList.add('active');

                    // Open the chat with the specific friend
                    const room = `chat-${Math.min(userId, friend.id)}-${Math.max(userId, friend.id)}`;
                    localStorage.setItem('currentRoom', room); // Save the current room
                    openChat(friend.username, friend.profile_pic, room);
                });

                friendsListContainer.appendChild(friendElement);
            });
        })
        .catch((error) => console.error('Error fetching friends:', error));
}

function makeLinksClickable(message) {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return message.replace(urlRegex, (url) => {
        return `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`;
    });
}

function fetchMessages() {
    const room = localStorage.getItem('currentRoom'); // Get the room name from localStorage
    const userId = parseInt(localStorage.getItem('userId'), 10); // Get the logged-in user's ID

    if (!room) {
        console.error('Room name not set. Cannot fetch messages.');
        return;
    }

    fetch(`/api/chat/getMessages?room=${room}`)
        .then((response) => response.json())
        .then((messages) => {
            const chatMessages = document.querySelector('.chat-messages');
            chatMessages.innerHTML = ''; // Clear current messages

            messages.forEach(({ sender_id, message, timestamp }) => {
                const messageDiv = document.createElement('div');

                if (sender_id === userId) {
                    messageDiv.classList.add('user-message'); // Sent by the current user
                } else {
                    messageDiv.classList.add('friend-message'); // Sent by the friend
                }

                messageDiv.innerHTML = `
                    <p>${makeLinksClickable(message)}
                        <span class="timestamp">${new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit'})}</span>
                    </p>
                `;
                chatMessages.appendChild(messageDiv);
            });

            chatMessages.scrollTop = chatMessages.scrollHeight; // Scroll to bottom
        })
        .catch((error) => console.error('Error fetching messages:', error));
}

function openChat(friendName, friendProfilePic, room) {
    const chatHeader = document.querySelector('.chat-header');

    // Set the header content using innerHTML
    chatHeader.innerHTML = `
        <img src="${friendProfilePic === '/default-profile-pic.jpg' 
            ? '../../resources/default-profile.jpg' 
            : `../../profilePics/${friendProfilePic}`}" 
            " 
            class="friend-pic" />
        <p class="friend-name">${friendName}</p>
    `;

    // Store the room name for future use
    localStorage.setItem('currentRoom', room);

    // Show the chat section UI
    document.querySelector('.chat-logo').style.display = 'none';
    document.querySelector('.chat-header').style.display = 'flex';
    document.querySelector('.chat-messages').style.display = 'block';
    document.querySelector('.message-input').style.display = 'flex';

    // Fetch and display messages for the selected room
    fetchMessages();
}

document.addEventListener('DOMContentLoaded', fetchFriends);
