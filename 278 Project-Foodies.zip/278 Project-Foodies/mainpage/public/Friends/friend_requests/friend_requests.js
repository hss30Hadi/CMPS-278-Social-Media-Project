document.addEventListener('DOMContentLoaded', () => {
    const userId = localStorage.getItem('userId'); // Logged-in user's ID
    const friendsSection = document.querySelector('.friends-section');
    const friendsGrid = document.querySelector('.friends-grid');

    if (!userId) {
        alert('You must be logged in to view friend requests.');
        return;
    }
    console.log('Fetching friend requests for user:', userId);

    function redirectToAccount(username, profilePicUrl) {
        if (username && profilePicUrl) {
            const encodedUsername = encodeURIComponent(username);
            const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
            window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
        } else {
            console.error("Invalid username or profile picture for redirection.");
        }
    }

    // Fetch friend requests sent to the logged-in user
    fetch(`/api/friend-requests/${userId}`)
        .then(response => response.json())
        .then(data => {
            console.log('Friend requests response:', data);

            friendsGrid.innerHTML = ''; // Clear any previous requests

            if (data.requests.length === 0) {
                // No friend requests
                const noRequestsMessage = document.createElement('p');
                noRequestsMessage.textContent = 'No friend requests sent to you.';
                noRequestsMessage.className = 'no-requests';
                friendsSection.appendChild(noRequestsMessage);
                return;
            }

            // Render friend requests
            data.requests.forEach(request => {
                const profilePicUrl = 
                request.profile_pic === '/default-profile-pic.jpg'
                    ? '../../resources/default-profile.jpg'
                    : `../../profilePics/${request.profile_pic}`;
                    
                const friendCard = document.createElement('div');
                friendCard.classList.add('friend-card');

                friendCard.innerHTML = `
                   <img src="${request.profile_pic === '/default-profile-pic.jpg' 
                    ? '../../resources/default-profile.jpg' 
                    : `../../profilePics/${request.profile_pic}`}" 
                    alt="${request.username}" 
                    class="friend-photo" />

                    <p class="friend-name">${request.username}</p>
                    <div class="friend-actions">
                        <button class="accept-btn" data-sender-id="${request.sender_id}">Accept</button>
                        <button class="reject-btn" data-sender-id="${request.sender_id}">Reject</button>
                    </div>
                `;

                friendsGrid.appendChild(friendCard);
                const friendNameElement = friendCard.querySelector('.friend-name');
            friendNameElement.addEventListener('click', () => {
                redirectToAccount(request.username, profilePicUrl);
            });
            });
        })
        .catch(error => {
            console.error('Error fetching friend requests:', error);
            const errorMessage = document.createElement('p');
            errorMessage.textContent = 'Failed to load friend requests.';
            errorMessage.className = 'error-message';
            friendsSection.appendChild(errorMessage);
        });
        
    // Handle Accept and Reject Buttons
    friendsGrid.addEventListener('click', (event) => {
        const target = event.target;

        if (target.classList.contains('accept-btn') || target.classList.contains('reject-btn')) {
            const senderId = target.getAttribute('data-sender-id');
            const action = target.classList.contains('accept-btn') ? 'accept' : 'reject';

            fetch(`/api/friends/${action}-friend-request`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ senderId, receiverId: userId })
            })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    target.closest('.friend-card').remove(); // Remove the card on action
                })
                .catch(error => {
                    console.error(`Error ${action}ing friend request:`, error);
                    alert(`Failed to ${action} friend request.`);
                });
        }
    });
});
