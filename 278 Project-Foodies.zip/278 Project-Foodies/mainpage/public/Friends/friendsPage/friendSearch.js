document.getElementById('search-button').addEventListener('click', async () => {
    const searchInput = document.getElementById('search-input').value.trim();
    const userId = localStorage.getItem('userId'); 
    const searchSection = document.querySelector('.search-section');
    const resultsContainer = document.getElementById('results-container');

    if (!searchInput) {
        alert('Please enter a username to search.');
        return;
    }

    if (!userId) {
        alert('You must be logged in to perform a search.');
        return;
    }

    function redirectToAccount(username, profilePicUrl) {
        if (username && profilePicUrl) {
            const encodedUsername = encodeURIComponent(username);
            const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
            window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
        } else {
            console.error("Invalid username or profile picture for redirection.");
        }
    }

    try {
        // Send search request to backend
        const response = await fetch(`/search?name=${encodeURIComponent(searchInput)}&userId=${encodeURIComponent(userId)}`);
        
        if (!response.ok) {
            if (response.status === 404) {
                resultsContainer.innerHTML = '<p class="not-found" style="margin-top: 120px; color: red;">No users found with this username.</p>';
                searchSection.classList.remove('results-shown'); // Keep search section in place
                return;
            }
            throw new Error('Failed to fetch search results.');
        }

        const results = await response.json();
        resultsContainer.innerHTML = ''; // Clear previous results

        if (results.length === 0) {
            resultsContainer.innerHTML = '<p class="not-found" style="margin-top: 120px; color: red;">No users found with this username.</p>';
            searchSection.classList.remove('results-shown');
            return;
        }

        // Iterate over the results and render user cards
        results.forEach(user => {
            const friendCard = document.createElement('div');
            friendCard.classList.add('friend-card');

            // Define profile picture URL
            const profilePicUrl = 
                user.profile_pic === '/default-profile-pic.jpg'
                    ? '../../resources/default-profile.jpg'
                    : `../../profilePics/${user.profile_pic}`;

            // Create friend card inner HTML
            friendCard.innerHTML = `
                <img src="${profilePicUrl}" 
                     alt="${user.username}" 
                     class="friend-photo" />
                <p class="friend-name" style="cursor: pointer;">${user.username}</p>
            `;

            // Add click event for the username to redirect to account.html
            const friendNameElement = friendCard.querySelector('.friend-name');
            friendNameElement.addEventListener('click', () => {
                redirectToAccount(user.username, profilePicUrl);
            });

            // Add friend actions
            const friendActions = document.createElement('div');
            friendActions.className = 'friend-actions';

            const addFriendBtn = document.createElement('button');
            addFriendBtn.className = 'add-friend-btn';
            addFriendBtn.setAttribute('data-user-id', user.id);

            // Check friendship_status and set button text and behavior
            if (user.friendship_status === 'friends') {
                addFriendBtn.textContent = 'Already Friends';
                addFriendBtn.classList.add('already-friends');
                addFriendBtn.disabled = true;
            } else if (user.friendship_status === 'request_sent') {
                addFriendBtn.textContent = 'Request Sent';
                addFriendBtn.classList.add('request-sent');
                addFriendBtn.disabled = true;
            } else {
                addFriendBtn.textContent = 'Add Friend';
                // Add event listener for sending friend request
                addFriendBtn.addEventListener('click', async (event) => {
                    const senderId = localStorage.getItem('userId');
                    const receiverId = event.target.getAttribute('data-user-id');

                    try {
                        const sendRequestResponse = await fetch('/api/friends/send-friend-request', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ senderId, receiverId }),
                        });

                        const data = await sendRequestResponse.json();

                        if (sendRequestResponse.ok && data.message === 'Friend request sent successfully.') {
                            event.target.textContent = 'Request Sent';
                            event.target.classList.add('request-sent');
                            event.target.disabled = true;
                        } else {
                            alert(data.message || 'Failed to send friend request.');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        alert('Failed to send friend request.');
                    }
                });
            }

            friendActions.appendChild(addFriendBtn);
            friendCard.appendChild(friendActions);
            resultsContainer.appendChild(friendCard);
        });

        searchSection.classList.add('results-shown'); // Move search section up
    } catch (error) {
        console.error('Error fetching search results:', error);
        resultsContainer.innerHTML = '<p class="error-message" style="margin-top: 120px; color: red;">Failed to fetch search results. Please try again later.</p>';
    }
});
