document.addEventListener('DOMContentLoaded', () => {
    const userId = localStorage.getItem('userId'); // Logged-in user's ID
    const friendsGrid = document.querySelector('.friends-grid');
    const friendsSection = document.querySelector('.friends-section');

    if (!userId) {
        alert('You must be logged in to view your friends.');
        return;
    }

    // Function to redirect to account.html
    function redirectToAccount(username, profilePicUrl) {
        if (username && profilePicUrl) {
            const encodedUsername = encodeURIComponent(username);
            const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
            // Use the correct relative path to account.html in Feed folder
            window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
        } else {
            console.error("Invalid username or profile picture for redirection.");
        }
    }

    // Fetch all friends
    fetch(`/api/friends/${userId}`)
        .then(response => {
            if (!response.ok) {
                if (response.status === 404) {
                    friendsGrid.innerHTML = '<p class="no-friends">You have no friends yet.</p>';
                    return [];
                }
                throw new Error('Failed to fetch friends list.');
            }
            return response.json();
        })
        .then(friends => {
            friendsGrid.innerHTML = ''; // Clear existing content

            if (friends.length === 0) {
                const noFriendsMessage = document.createElement('p');
                noFriendsMessage.textContent = 'You have no friends yet.';
                noFriendsMessage.className = 'no-friends';
                friendsSection.appendChild(noFriendsMessage);
                return;
            }

            // Render friends
            friends.forEach(friend => {
                const friendCard = document.createElement('div');
                friendCard.classList.add('friend-card');

                // Define the profile picture URL
                const profilePicUrl =
                    friend.profile_pic === '/default-profile-pic.jpg'
                        ? '../../resources/default-profile.jpg'
                        : `../../profilePics/${friend.profile_pic}`;

                friendCard.innerHTML = `
                    <img src="${profilePicUrl}" 
                         alt="${friend.username}" 
                         class="friend-photo" />
                    <p class="friend-name" style="cursor: pointer">${friend.username}</p>
                `;

                // Add click event to redirect on friend's name
                const friendNameElement = friendCard.querySelector('.friend-name');
                friendNameElement.addEventListener('click', () => {
                    redirectToAccount(friend.username, profilePicUrl);
                });

                friendsGrid.appendChild(friendCard);
            });
        })
        .catch(error => {
            console.error('Error fetching friends:', error);
            friendsGrid.innerHTML = '<p class="error-message">Failed to load friends. Please try again later.</p>';
        });
});
