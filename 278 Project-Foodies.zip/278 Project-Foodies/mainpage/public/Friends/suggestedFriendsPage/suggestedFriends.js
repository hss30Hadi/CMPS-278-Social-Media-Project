async function fetchSuggestedFriends() {
    const userId = localStorage.getItem('userId'); // Retrieve logged-in user ID
  
    if (!userId) {
      console.error('User not logged in or invalid userId');
      return;
    }
  
    try {
      const response = await fetch(`http://localhost:3000/suggested-friends/${userId}`);
      if (response.ok) {
        const friends = await response.json();
        renderSuggestedFriends(friends);
      } else {
        console.error('Error fetching suggested friends:', response.statusText);
      }
    } catch (error) {
      console.error('Error fetching suggested friends:', error);
    }
  }
  
  function renderSuggestedFriends(friends) {
    const friendsGrid = document.querySelector('.friends-grid');
    friendsGrid.innerHTML = ''; // Clear previous suggestions
  
    if (friends.length === 0) {
      // Display message when no suggestions are available
      friendsGrid.innerHTML = `
        <div class="no-suggestions">
          <p>There are no friends to be suggested.</p>
        </div>
      `;
      return;
    }
  // Function to redirect to account.html
  function redirectToAccount(username, profilePicUrl) {
    if (username && profilePicUrl) {
        const encodedUsername = encodeURIComponent(username);
        const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
        window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
    } else {
        console.error("Invalid username or profile picture for redirection.");
    }
}
    // Render suggested friends
    friends.forEach(user => {
      const friendCard = document.createElement('div');
      friendCard.classList.add('friend-card');
  
      // Create the friend actions container
      const friendActions = document.createElement('div');
      friendActions.className = 'friend-actions';
  
      const addFriendBtn = document.createElement('button');
      addFriendBtn.className = 'add-friend-btn';
      addFriendBtn.setAttribute('data-user-id', user.id);
  
      // Check friendship_status and set button text and behavior
      if (user.friendship_status === 'friends') {
        addFriendBtn.textContent = 'Already Friends';
        addFriendBtn.classList.add('already-friends');
        addFriendBtn.disabled = true;
      } else if (user.friendship_status === 'request_sent') {
        addFriendBtn.textContent = 'Request Sent';
        addFriendBtn.classList.add('request-sent');
        addFriendBtn.disabled = true;
      } else {
        addFriendBtn.textContent = 'Add Friend';
        // Add event listener for sending friend request
        addFriendBtn.addEventListener('click', async (event) => {
          const senderId = localStorage.getItem('userId');
          const receiverId = event.target.getAttribute('data-user-id');
  
          try {
            const sendRequestResponse = await fetch('/api/friends/send-friend-request', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ senderId, receiverId }),
            });
  
            const data = await sendRequestResponse.json();
  
            if (sendRequestResponse.ok && data.message === 'Friend request sent successfully.') {
              event.target.textContent = 'Request Sent';
              event.target.classList.add('request-sent');
              event.target.disabled = true;
            } else {
              alert(data.message || 'Failed to send friend request.');
            }
          } catch (error) {
            console.error('Error:', error);
            alert('Failed to send friend request.');
          }
        });
      }
  
      friendActions.appendChild(addFriendBtn);
  
      // Render user card with profile picture
      const friendPhoto = document.createElement('img');
      friendPhoto.className = 'friend-photo';
      friendPhoto.src = user.profile_pic && user.profile_pic !== '/default-profile-pic.jpg'
        ? `../../profilePics/${user.profile_pic}`
        : '../../resources/default-profile.jpg';
      friendPhoto.alt = `${user.username}`;
  
      const friendName = document.createElement('p');
      friendName.className = 'friend-name';
      friendName.textContent = user.username;
      friendName.addEventListener('click', () => {
        redirectToAccount(user.username, user.profile_pic && user.profile_pic !== '/default-profile-pic.jpg'
            ? `../../profilePics/${user.profile_pic}`
            : '../../resources/default-profile.jpg');
    });
      friendCard.appendChild(friendPhoto);
      friendCard.appendChild(friendName);
      friendCard.appendChild(friendActions);
      friendsGrid.appendChild(friendCard);
    });
  }
  
  // Call the fetchSuggestedFriends function when the page loads
  document.addEventListener('DOMContentLoaded', fetchSuggestedFriends);
  