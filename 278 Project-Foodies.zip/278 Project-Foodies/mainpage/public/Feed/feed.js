document.addEventListener('DOMContentLoaded', () => {
    const userId = localStorage.getItem('userId'); 
    function redirectToAccount(username, profilePicUrl) {
        if (username && profilePicUrl) {
            const encodedUsername = encodeURIComponent(username);
            const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
            window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
        } else {
            console.error("Invalid username or profile picture for redirection.");
        }
    }
    fetch(`/feed?userId=${userId}`)
        .then((response) => response.json())
        .then((posts) => {
            const feedContainer = document.querySelector('.image-grid');
            feedContainer.innerHTML = '';

            posts.forEach((post) => {
                const postElement = document.createElement('div');
                postElement.classList.add('post');

                const profilePicUrl = 
                `${post.profile_pic === '/default-profile-pic.jpg' 
                ? '../../profilePics/default-profile.jpg' 
                : `../../profilePics/${post.profile_pic}`}`;

                const postImageUrl = `../../${post.image_url}`;

                const likes = post.liked_by ? post.liked_by.split(',').length : 0;
                const dislikes = post.disliked_by ? post.disliked_by.split(',').length : 0;
                const userLiked = post.liked_by?.includes(userId);
                const userDisliked = post.disliked_by?.includes(userId);

                postElement.innerHTML = `
                <div class="post-container">
                    <div class="post-header">
                        <img src="${profilePicUrl}" alt="${post.username}" class="profile-pic" />
                        <span class="username" style="cursor: pointer">${post.username}</span>
                    </div>
                    <div class="post-content">
                        ${
                            post.image_url
                                ? `<img src="${postImageUrl}" alt="Post image" class="post-image" />`
                                : ''
                        }
                        <p>${post.post_text}</p>
                    </div>
                    <div class="post-footer">
                        <span class="reaction">
                            <button class="like-btn ${userLiked ? 'active' : ''}" data-post-id="${post.post_id}">
                                👍 <span class="like-count">${likes}</span>
                            </button>
                            <button class="dislike-btn ${userDisliked ? 'active' : ''}" data-post-id="${post.post_id}">
                                👎 <span class="dislike-count">${dislikes}</span>
                            </button><button class="comment-btn">💬</button>
<button class="share-btn" data-post-id="${post.post_id}">📬Share</button>                        </span>
                        <div class="dropdown" style="display: none;">
            <select class="friends-dropdown"></select>
            <button class="send-btn" style="display: none;">Send</button>
        </div>
                        <div class="comments-section"></div>
                        <input type="text" class="comment-input" placeholder="Write a comment...">
                        <button class="submit-comment-btn" data-post-id="${post.post_id}">Post Comment</button>
                        <span>${new Date(post.created_at).toLocaleString('en-US', {
                            hour: '2-digit',
                            minute: '2-digit',
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                        })}</span>
                    </div>
                </div>
                `;
                const usernameElement = postElement.querySelector('.username');
                usernameElement.addEventListener('click', () => {
                    redirectToAccount(post.username, profilePicUrl); // Pass the username and profile picture URL
                });
                
                feedContainer.appendChild(postElement);

                const likeBtn = postElement.querySelector('.like-btn');
                const dislikeBtn = postElement.querySelector('.dislike-btn');
                const commentBtn = postElement.querySelector('.comment-btn');
                const submitCommentBtn = postElement.querySelector('.submit-comment-btn');
                const commentInput = postElement.querySelector('.comment-input');
                const commentsSection = postElement.querySelector('.comments-section');
                const shareBtn = postElement.querySelector('.share-btn');
const dropdownDiv = postElement.querySelector('.dropdown');
const friendsDropdown = dropdownDiv.querySelector('.friends-dropdown');
const sendBtn = dropdownDiv.querySelector('.send-btn');
// Handle share button click
shareBtn.addEventListener('click', () => {
    dropdownDiv.style.display = dropdownDiv.style.display === 'none' ? 'block' : 'none';

    // Fetch user's friends
    fetch(`/api/friends/${userId}`)
        .then((res) => res.json())
        .then((friends) => {
            friendsDropdown.innerHTML = ''; // Clear previous options
            friends.forEach((friend) => {
                const option = document.createElement('option');
                option.value = friend.id;
                option.textContent = friend.username;
                friendsDropdown.appendChild(option);
            });
            sendBtn.style.display = 'block';
        })
        .catch((err) => console.error('Error fetching friends:', err));
});
// Handle send button click
sendBtn.addEventListener('click', () => {
    const selectedFriendId = friendsDropdown.value;
    const sharedUserName = post.username; // Extract the username of the post's creator
    const profilePicUrl = post.profile_pic ? post.profile_pic : '/default-profile-pic.jpg';

    // Construct the message with the link to the shared user's account
    const message = `Check out ${sharedUserName}'s profile: http://localhost:3000/../../Feed/account.html?username=${encodeURIComponent(sharedUserName)}&profilePic=${encodeURIComponent(post.profile_pic)}&viewerId=${userId}`;


    sendBtn.disabled = true; // Disable button during the request
    fetch('/send-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            senderId: userId,
            receiverId: selectedFriendId,
            message,
        }),
    })
        .then((res) => {
            if (res.ok) {
                alert('Post shared successfully!');
                dropdownDiv.classList.remove('visible');
            } else {
                alert('Failed to share the post.');
            }
        })
        .catch((err) => console.error('Error sending message:', err))
        .finally(() => {
            sendBtn.disabled = false; // Re-enable button
        });
});

                // Like button click
                likeBtn.addEventListener('click', () => {
                    fetch(`/post/${post.post_id}/reaction`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId, reaction: 'like' }),
                    })
                        .then((res) => res.json())
                        .then(({ likes, dislikes }) => {
                            postElement.querySelector('.like-count').textContent = likes;
                            postElement.querySelector('.dislike-count').textContent = dislikes;
                            likeBtn.classList.add('active');
                            dislikeBtn.classList.remove('active');
                        })
                        .catch((err) => console.error(err));
                });

                // Dislike button click
                dislikeBtn.addEventListener('click', () => {
                    fetch(`/post/${post.post_id}/reaction`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId, reaction: 'dislike' }),
                    })
                        .then((res) => res.json())
                        .then(({ likes, dislikes }) => {
                            postElement.querySelector('.like-count').textContent = likes;
                            postElement.querySelector('.dislike-count').textContent = dislikes;
                            dislikeBtn.classList.add('active');
                            likeBtn.classList.remove('active');
                        })
                        .catch((err) => console.error(err));
                });

                // Comment button click
                commentBtn.addEventListener('click', () => {
                    fetch(`/post/${post.post_id}/comments`)
                        .then((response) => response.json())
                        .then((comments) => {
                            commentsSection.innerHTML = comments.map((comment) => {
                                const commentLikes = comment.liked_by ? comment.liked_by.split(',').length : 0;
                                const commentDislikes = comment.disliked_by ? comment.disliked_by.split(',').length : 0;
                                const userCommentLiked = comment.liked_by?.includes(userId);
                                const userCommentDisliked = comment.disliked_by?.includes(userId);
                                
                                return `
                                    <div class="comment">
                                        <div class="comment-header">
                                            <img src="${comment.profile_pic === '/default-profile-pic.jpg' 
                                            ? '../../profilePics/default-profile.jpg' 
                                            : `../../profilePics/${comment.profile_pic}`}" 
                                            alt="${comment.username}" 
                                            class="comment-profile-pic" />                
                                            <span class="comment-username">${comment.username}</span>
                                        </div>
                                        <div class="comment-text">${comment.comment_text}</div>
                                        <div class="comment-footer">
                                            <span class="reaction">
                                                <button class="like-btn ${userCommentLiked ? 'active' : ''}" data-comment-id="${comment.comment_id}">
                                                    👍 <span class="like-count">${commentLikes}</span>
                                                </button>
                                                <button class="dislike-btn ${userCommentDisliked ? 'active' : ''}" data-comment-id="${comment.comment_id}">
                                                    👎 <span class="dislike-count">${commentDislikes}</span>
                                                </button>
                                            </span>
                                        </div>
                                    </div>
                                `;
                            }).join('');
                
                            // Add event listeners for like and dislike buttons in comments
                            commentsSection.querySelectorAll('.like-btn').forEach(likeBtn => {
                                likeBtn.addEventListener('click', () => {
                                    const commentId = likeBtn.dataset.commentId;
                                    fetch(`/comment/${commentId}/reaction`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ userId, reaction: 'like' }),
                                    })
                                    .then(res => res.json())
                                    .then(({ likes, dislikes }) => {
                                        likeBtn.querySelector('.like-count').textContent = likes;
                                        likeBtn.closest('.comment').querySelector('.dislike-btn .dislike-count').textContent = dislikes;
                                        likeBtn.classList.add('active');
                                        likeBtn.closest('.comment').querySelector('.dislike-btn').classList.remove('active');
                                    })
                                    .catch(err => console.error(err));
                                });
                            });
                
                            commentsSection.querySelectorAll('.dislike-btn').forEach(dislikeBtn => {
                                dislikeBtn.addEventListener('click', () => {
                                    const commentId = dislikeBtn.dataset.commentId;
                                    fetch(`/comment/${commentId}/reaction`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ userId, reaction: 'dislike' }),
                                    })
                                    .then(res => res.json())
                                    .then(({ likes, dislikes }) => {
                                        dislikeBtn.querySelector('.dislike-count').textContent = dislikes;
                                        dislikeBtn.closest('.comment').querySelector('.like-btn .like-count').textContent = likes;
                                        dislikeBtn.classList.add('active');
                                        dislikeBtn.closest('.comment').querySelector('.like-btn').classList.remove('active');
                                    })
                                    .catch(err => console.error(err));
                                });
                            });
                        });
                });
                

                // Submit comment button click
                submitCommentBtn.addEventListener('click', () => {
                    const commentText = commentInput.value.trim();
                    if (commentText) {
                        fetch(`/post/${post.post_id}/comment`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ userId, commentText }),
                        })
                            .then(() => {
                                commentInput.value = '';
                                commentBtn.click();  // Refresh comments list
                            })
                            .catch((err) => console.error(err));
                    }
                });
            });
        })
        .catch((error) => console.error('Error fetching posts:', error));
});

function logout(){
    window.location.href = '../login_sign up/login.html'; 
}




async function fetchTopContributor() {
    const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

    if (!userId) {
        console.error('User not logged in or invalid userId');
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/top-contributor/${userId}`);
        if (response.ok) {
            const contributor = await response.json();

            // Check for a valid contributor
            if (contributor.contribution > 0) {
                const contributorPic = document.getElementById('contributorPic');
                const contributorName = document.getElementById('contributorName');

                contributorPic.src = 
                    contributor.profile_pic === '/default-profile-pic.jpg'
                        ? '../../profilePics/default-profile.jpg'
                        : `../../profilePics/${contributor.profile_pic}`;
                contributorName.textContent = contributor.username;
                contributorName.style.cursor = 'pointer'; // Make it clickable

                // Add click event for redirection
                contributorName.addEventListener('click', () => {
                    redirectToAccount(
                        contributor.username,
                        contributor.profile_pic === '/default-profile-pic.jpg'
                            ? '../../profilePics/default-profile.jpg'
                            : `../../profilePics/${contributor.profile_pic}`
                    );
                });
            } else {
                document.getElementById('contributorPic').src = '../../profilePics/default-profile.jpg'; // Fallback image
                document.getElementById('contributorName').textContent = 'None of your friends have contributed yet.';
                document.getElementById('contributorName').style.color = 'red';
            }
        } else {
            document.getElementById('contributorPic').src = '../../profilePics/default-profile.jpg'; // Fallback image
            document.getElementById('contributorName').textContent = 'None of your friends have contributed yet.';
            document.getElementById('contributorName').style.color = 'red';
        }
    } catch (error) {
        console.error('Error fetching top contributor:', error);
        document.getElementById('contributorName').textContent = 'An error occurred.';
    }
}

async function fetchMostActive() {
    const userId = localStorage.getItem('userId'); // Retrieve the logged-in user ID

    if (!userId) {
        console.error('User not logged in or invalid userId');
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/most-active/${userId}`);
        if (response.ok) {
            const activity = await response.json();

            // Check for valid activity
            if (activity.activity > 0) {
                const activityPic = document.getElementById('activityPic');
                const activityName = document.getElementById('activityName');

                activityPic.src = 
                    activity.profile_pic === '/default-profile-pic.jpg'
                        ? '../../profilePics/default-profile.jpg'
                        : `../../profilePics/${activity.profile_pic}`;
                activityName.textContent = activity.username;
                activityName.style.cursor = 'pointer'; // Make it clickable

                // Add click event for redirection
                activityName.addEventListener('click', () => {
                    redirectToAccount(
                        activity.username,
                        activity.profile_pic === '/default-profile-pic.jpg'
                            ? '../../profilePics/default-profile.jpg'
                            : `../../profilePics/${activity.profile_pic}`
                    );
                });
            } else {
                document.getElementById('activityPic').src = '../../profilePics/default-profile.jpg'; // Fallback image
                document.getElementById('activityName').textContent = 'None of your friends have done any activity yet.';
                document.getElementById('activityName').style.color = 'red';
            }
        } else {
            document.getElementById('activityPic').src = '../../profilePics/default-profile.jpg'; // Fallback image
            document.getElementById('activityName').textContent = 'None of your friends have done any activity yet.';
            document.getElementById('activityName').style.color = 'red';
        }
    } catch (error) {
        console.error('Error fetching most active friend:', error);
        document.getElementById('activityName').textContent = 'An error occurred.';
        document.getElementById('activityName').style.color = 'red';
    }
}
  
function redirectToAccount(username, profilePicUrl) {
    if (username && profilePicUrl) {
        const encodedUsername = encodeURIComponent(username);
        const encodedProfilePicUrl = encodeURIComponent(profilePicUrl);
        window.location.href = `../../Feed/account.html?username=${encodedUsername}&profilePic=${encodedProfilePicUrl}`;
    } else {
        console.error("Invalid username or profile picture for redirection.");
    }
}
  // Call the function when the page loads
  document.addEventListener('DOMContentLoaded', fetchTopContributor);
  document.addEventListener('DOMContentLoaded', fetchMostActive);

  