document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get("username");
    const profilePic = urlParams.get("profilePic");

    if (!username) {
        alert("Username not provided.");
        return;
    }

    document.getElementById("username").textContent = username;
    document.getElementById("profilePicture").src = profilePic && profilePic.endsWith('default-profile-pic.jpg') 
        ? '../../resources/default-profile.jpg' 
        : `../../profilePics/${decodeURIComponent(profilePic)}`;

    const uniquePostIds = new Set();

    fetch(`/get-user-id?username=${username}`)
        .then((response) => response.json())
        .then(({ userId }) => {
            if (!userId) {
                alert("Failed to load user ID. Please try again later.");
                return;
            }

            const viewerId = localStorage.getItem('userId');
            if (!viewerId) {
                console.error("Viewer ID not found in localStorage.");
                alert("Please log in to see friends' posts.");
                return;
            }

            Promise.all([
                fetch(`/user-posts-public/${userId}`).then((response) => response.json()),
                fetch(`/user-posts-friends/${viewerId}/${userId}`).then((response) => response.json())
            ])
            .then(([publicPosts, friendPosts]) => {
                const posts = [...publicPosts, ...friendPosts];
                const postsGrid = document.getElementById("postsGrid");
                postsGrid.innerHTML = ""; // Clear existing posts

                posts.forEach((post) => {
                    if (post.post_id && !uniquePostIds.has(post.post_id)) {
                        uniquePostIds.add(post.post_id);
                        const postElement = createPostElement(post);
                        postsGrid.appendChild(postElement);
                    }
                });

                document.getElementById("postCount").textContent = uniquePostIds.size;
            })
            .catch((error) => {
                console.error("Error fetching posts:", error);
                alert("Failed to load posts. Please try again later.");
            });

            fetch(`/user-friends-count/${userId}`)
                .then((response) => response.json())
                .then(({ nbFriends }) => {
                    document.getElementById("followersCount").textContent = nbFriends;
                })
                .catch((error) => {
                    console.error("Error fetching followers count:", error);
                    alert("Failed to load followers count. Please try again later.");
                });
        })
        .catch((error) => {
            console.error("Error fetching user ID:", error);
            alert("Failed to load user ID. Please try again later.");
        });

    function createPostElement(post) {
        const postElement = document.createElement("div");
        postElement.classList.add("post");
        postElement.innerHTML = `
            <img src="${post.image_url || '../../resources/placeholder-image.jpg'}" alt="User Post" class="user-post-image" />
            <p>${post.post_text || ""}</p>
            <span>${post.created_at ? new Date(post.created_at).toLocaleString() : "Unknown Date"}</span>
        `;
        return postElement;
    }

    document.querySelector(".back-button").addEventListener("click", function () {
        window.history.back();
    });
});
