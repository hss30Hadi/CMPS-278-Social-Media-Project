require('dotenv').config();
const express = require('express');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const nodemailer = require('nodemailer');
const crypto = require('crypto');



const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/profilePics', express.static(path.join(__dirname, 'profilePics')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(__dirname));
app.use(express.static('public'));
// Connect to MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'myappdb'
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to MySQL database.');
});

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_APP_PASSWORD
  }
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public','login_sign up', 'login.html'));
});



// Function to generate a 6-digit code
function generateVerificationCode() {
    return Math.floor(100000 + Math.random() * 900000).toString(); // Generates a number between 100000 and 999999
  }

  // Login route
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
  
    // Find user by email
    db.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error('Database query error:', error);
        return res.status(500).json({ message: 'Server error' });
      }
      
      // Check if user exists
      if (results.length === 0) {
        return res.status(400).json({ message: 'User not found' });
      }
  
      const user = results[0];
      if (user.is_verified === 0) {
        return res.status(403).json({
          message: 'Your account is not verified. Please verify your account to continue.',
          redirectTo: '../login_sign up/verification.html'
        });
      }
      // Verify password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
  
      // Login successful
      res.status(200).json({ message: 'Login successful', user: { id: user.id, email: user.email } });
    });
  });
  
  app.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;
  
    // Check if the user already exists
    db.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
      if (error) return res.status(500).json({ error });
      if (results.length > 0) return res.status(400).json({ message: 'User already exists' });
  
      // Hash the password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
  
      // Generate a 6-digit verification code
      const verificationCode = generateVerificationCode();
  
      // Insert new user with verification code
      db.query(
        'INSERT INTO users (username, email, password, verification_code) VALUES (?, ?, ?, ?)',
        [username, email, hashedPassword, verificationCode],
        (error, results) => {
          if (error) return res.status(500).json({ error });
  
          // Send the 6-digit verification code via email
          const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Verify Your Account',
            text: `Thank you for signing up to Foodies Application!\n Please use the following verification code to activate your account:\t ${verificationCode}`
          };
  
          transporter.sendMail(mailOptions, (err, info) => {
            if (err) {
              console.error('Error sending email:', err);
              return res.status(500).json({ message: 'Error sending verification email' });
            }
            console.log('Verification email sent:', info.response);
  
            // Send a response indicating success and the need to verify the account
            res.status(201).json({ message: 'User registered successfully. Please check your email to verify your account.', redirectTo: '/verify' });
          });
        }
      );
    });
  });
  app.post('/verify', (req, res) => {
    const { email, verificationCode } = req.body; // Include email for identifying the user
  
    // Query the database to find the user by email and check the verification code
    db.query(
      'SELECT * FROM users WHERE email = ? AND verification_code = ?',
      [email, verificationCode],
      (error, results) => {
        if (error) {
          console.error('Database error during verification:', error);
          return res.status(500).json({ message: 'Server error during verification' });
        }
  
        if (results.length === 0) {
          return res.status(400).json({ message: 'Invalid verification code' });
        }
  
        // If verification code matches, update the user's status to "verified"
        db.query(
          'UPDATE users SET is_verified = 1 WHERE email = ?',
          [email],
          (updateError) => {
            if (updateError) {
              console.error('Error updating user verification status:', updateError);
              return res.status(500).json({ message: 'Error verifying account' });
            }
  
            res.status(200).json({ message: 'Account verified successfully!' });
          }
        );
      }
    );
  });
  // Request reset code endpoint
  app.post('/request-reset', (req, res) => {
    const { email } = req.body;
  
    db.query('SELECT * FROM users WHERE email = ?', [email], (error, results) => {
      if (error) return res.status(500).json({ error: 'Server error' });
      if (results.length === 0) return res.status(400).json({ message: 'User not found' });
  
      const verificationCode = generateVerificationCode();
      console.log(`Generated verification code for ${email}: ${verificationCode}`);
  
      // Update the user record with the new reset code
      db.query(
        'UPDATE users SET reset_token = ? WHERE email = ?',
        [verificationCode, email],
        (updateError) => {
          if (updateError) return res.status(500).json({ error: 'Error saving reset code' });
  
          const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Password Reset Verification Code',
            text: `Use this verification code to reset your password: ${verificationCode}`
          };
  
          transporter.sendMail(mailOptions, (err) => {
            if (err) return res.status(500).json({ message: 'Error sending verification code' });
            res.status(200).json({ message: 'Verification code sent to your email.' });
          });
        }
      );
    });
  });
  // Reset password endpoint without expiry check
  app.post('/reset-password', async (req, res) => {
    const { email, token, newPassword } = req.body;
  
    console.log(`Received reset request for ${email} with provided token: ${token}`);
  
    db.query(
      'SELECT * FROM users WHERE email = ?',
      [email],
      async (error, results) => {
        if (error) return res.status(500).json({ message: 'Server error' });
  
        if (results.length === 0) {
          console.log(`User not found: ${email}`);
          return res.status(400).json({ message: 'User not found' });
        }
  
        const user = results[0];
        console.log(`Retrieved reset token from database for ${email}: ${user.reset_token}`);
  
        // Check if the provided token matches exactly
        if (user.reset_token !== token) {
          console.log(`Provided token does not match stored token for ${email}`);
          return res.status(400).json({ message: 'Invalid reset token' });
        }
  
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);
  
        db.query(
          'UPDATE users SET password = ?, reset_token = NULL WHERE email = ?',
          [hashedPassword, email],
          (updateError) => {
            if (updateError) return res.status(500).json({ message: 'Error updating password' });
            console.log(`Password reset successful for ${email}`);
            res.status(200).json({ message: 'Password has been reset successfully' });
          }
        );
      }
    );
  });
app.get('/users', (req, res) => {
  db.query('SELECT * FROM users', (error, results) => {
    if (error) return res.status(500).json({ error });
    res.status(200).json(results);
  });
});

// Search
app.get('/search', (req, res) => {
  const searchQuery = req.query.name.trim();
  const userId = req.query.userId;

  if (!searchQuery || !userId) {
      return res.status(400).json({ message: 'Invalid search parameters.' });
  }

  const query = `
      SELECT 
          u.id, 
          u.username, 
          u.profile_pic,
          CASE
              WHEN fr.status = 'friends' THEN 'friends'
              WHEN fr.status = 'request_sent' AND fr.sender_id = ? THEN 'request_sent'
              WHEN fr.status = 'request_sent' AND fr.receiver_id = ? THEN 'received_request'
              ELSE NULL
          END AS friendship_status
      FROM users u
      LEFT JOIN friend_requests fr 
          ON (fr.sender_id = u.id AND fr.receiver_id = ?) 
          OR (fr.sender_id = ? AND fr.receiver_id = u.id)
      WHERE u.username LIKE ? AND u.id != ? AND u.is_verified = 1
      LIMIT 10;
  `;

  db.query(
      query, 
      [userId, userId, userId, userId, `%${searchQuery}%`, userId], 
      (err, results) => {
          if (err) {
              console.error('Database error:', err);
              return res.status(500).json({ message: 'Database error.' });
          }

          res.json(results);
      }
  );
});
// Suggested Friends Routes******************************************************************************
app.get('/suggested-friends/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId) {
    return res.status(400).json({ message: 'Invalid user ID' });
  }

  const query = `
    WITH MostActiveFriends AS (
        SELECT f.friend_id
        FROM friends f
        JOIN users u ON f.friend_id = u.id
        WHERE f.user_id = ?
        ORDER BY u.activity DESC
        LIMIT 3
    ),
    FriendsOfMostActive AS (
        SELECT f.friend_id
        FROM friends f
        JOIN MostActiveFriends maf ON f.user_id = maf.friend_id
        JOIN users u ON f.friend_id = u.id
        WHERE f.friend_id NOT IN (
            SELECT friend_id 
            FROM friends 
            WHERE user_id = ?
        )
        AND f.friend_id != ?
        ORDER BY u.activity DESC
        LIMIT 9
    )
    SELECT u.id, u.username, u.profile_pic,
           CASE
               WHEN fr.status = 'friends' THEN 'friends'
               WHEN fr.status = 'request_sent' AND fr.sender_id = ? THEN 'request_sent'
               ELSE NULL
           END AS friendship_status
    FROM users u
    JOIN FriendsOfMostActive foa ON u.id = foa.friend_id
    LEFT JOIN friend_requests fr ON 
        (fr.sender_id = u.id AND fr.receiver_id = ?) 
        OR (fr.sender_id = ? AND fr.receiver_id = u.id)
    WHERE u.is_verified = 1;
  `;

  db.query(query, [userId, userId, userId, userId, userId, userId], (err, results) => {
    if (err) {
      console.error('Error fetching suggested friends:', err);
      return res.status(500).json({ message: 'Error fetching suggested friends' });
    }

    res.json(results);
  });
});


// Friend Request Routes
// Send Friend Request
app.post('/api/friends/send-friend-request', (req, res) => {
  const { senderId, receiverId } = req.body;

  if (!senderId || !receiverId) {
      console.error('Missing sender or receiver ID:', { senderId, receiverId });
      return res.status(400).json({ error: 'Missing sender or receiver ID.' });
  }

  const query = `
      INSERT INTO friend_requests (sender_id, receiver_id)
      VALUES (?, ?)
  `;

  db.query(query, [senderId, receiverId], (err) => {
      if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Error sending friend request.' });
      }

      res.status(200).json({ message: 'Friend request sent successfully.' });
  });
});

// Accept Friend Request************************************************************************
app.post('/api/friends/accept-friend-request', (req, res) => {
  const { senderId, receiverId } = req.body;

  if (!senderId || !receiverId) {
      console.error('Missing sender or receiver ID:', { senderId, receiverId });
      return res.status(400).json({ error: 'Missing sender or receiver ID.' });
  }

  const addFriendQuery = `
      INSERT INTO friends (user_id, friend_id)
      VALUES (?, ?), (?, ?)
  `;
  const UpdateRequestQuery = `
     UPDATE friend_requests
        SET status = 'friends'
        WHERE sender_id = ? AND receiver_id = ? AND status = 'request_sent';
  `;

  db.beginTransaction((err) => {
      if (err) {
          console.error('Transaction error:', err);
          return res.status(500).json({ error: 'Transaction error.' });
      }

      db.query(addFriendQuery, [receiverId, senderId, senderId, receiverId], (err) => {
          if (err) {
              console.error('Error adding friends:', err);
              return db.rollback(() => res.status(500).json({ error: 'Error adding friends.' }));
          }

          db.query(UpdateRequestQuery, [senderId, receiverId], (err) => {
              if (err) {
                  console.error('Error updating friend request:', err);
                  return db.rollback(() => res.status(500).json({ error: 'Error updating friend request.' }));
              }

              db.commit((err) => {
                  if (err) {
                      console.error('Commit error:', err);
                      return res.status(500).json({ error: 'Commit error.' });
                  }
                  res.status(200).json({ message: 'Friend request accepted.' });
              });
          });
      });
  });
});

// Reject Friend Request
app.post('/api/friends/reject-friend-request', (req, res) => {
  const { senderId, receiverId } = req.body;

  if (!senderId || !receiverId) {
      console.error('Missing sender or receiver ID:', { senderId, receiverId });
      return res.status(400).json({ error: 'Missing sender or receiver ID.' });
  }

  const query = `
      DELETE FROM friend_requests
      WHERE sender_id = ? AND receiver_id = ?
  `;

  db.query(query, [senderId, receiverId], (err) => {
      if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Error rejecting friend request.' });
      }

      res.status(200).json({ message: 'Friend request rejected.' });
  });
});

// Get Friends List


app.get('/api/friend-requests/:userId', (req, res) => {
  const { userId } = req.params;
  const query = `
      SELECT fr.sender_id, u.username, u.profile_pic
      FROM friend_requests fr
      JOIN users u ON fr.sender_id = u.id
      WHERE fr.receiver_id = ? AND fr.status = 'request_sent';
  `;

  db.query(query, [userId], (err, results) => {
      if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Error fetching friend requests.' });
      }

      res.status(200).json({ requests: results });
  });
});



app.get('/api/friends/:userId', (req, res) => {
  const { userId } = req.params;

  const query = `
      SELECT u.id, u.username, u.profile_pic
      FROM friends f
      JOIN users u 
      ON (f.friend_id = u.id AND f.user_id = ?);
  `;

  db.query(query, [userId], (err, results) => {
      if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Error fetching friends list.' });
      }

      if (results.length === 0) {
          return res.status(404).json({ message: 'No friends found.' });
      }

      res.status(200).json(results);
  });
});

// Profile delete account button

app.delete('/delete-account/:userId', (req, res) => {
  const { userId } = req.params;

  if (!userId) {
    return res.status(400).json({ message: 'User ID is required' });
  }

  // First, delete all posts of the user
  db.query('DELETE FROM posts WHERE user_id = ?', [userId], (error, results) => {
    if (error) {
      console.error('Error deleting posts:', error);
      return res.status(500).json({ message: 'Failed to delete user posts' });
    }

    // Then, delete the user
    db.query('DELETE FROM users WHERE id = ?', [userId], (error, results) => {
      if (error) {
        console.error('Error deleting user:', error);
        return res.status(500).json({ message: 'Failed to delete user account' });
      }

      res.status(200).json({ message: 'Account and associated posts deleted successfully' });
    });
  });
});



// Chat code********************************************************************************************************

app.post('/api/chat/sendMessage', (req, res) => {
  const { room, sender, message } = req.body;

  if (!room || !sender || !message) {
      return res.status(400).json({ success: false, error: 'Invalid request data' });
  }

  const insertMessageQuery = 'INSERT INTO messages (room, sender_id, message) VALUES (?, ?, ?)';
  db.query(insertMessageQuery, [room, sender, message], (err) => {
      if (err) {
          console.error('Database error while inserting message:', err);
          return res.status(500).json({ success: false, error: 'Database error' });
      }
      res.status(200).json({ success: true });
  });
});

app.get('/api/chat/getMessages', (req, res) => {
  const { room } = req.query;

  if (!room) {
      return res.status(400).json({ error: 'Room parameter is required' });
  }

  const query = `
  SELECT sender_id, message, 
  DATE_FORMAT(CONVERT_TZ(timestamp, @@session.time_zone, '+00:00'), '%Y-%m-%dT%H:%i:%sZ') as timestamp
  FROM messages
  WHERE room = ?
  ORDER BY timestamp ASC;
`;

  db.query(query, [room], (err, results) => {
      if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Database error' });
      }
      res.status(200).json(results);
  });
});

// Create folder backend***********************************************************
const upload = multer({
  dest: 'uploads/', // Temporary storage for uploaded files
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB size limit
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.post('/create-post', upload.single('file'), (req, res) => {
  try {
    const userId = req.body.userId;
    const { description, visibility } = req.body;
    const file = req.file;

    if (!description || !visibility || !file) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    const imageUrl = `/uploads/${file.filename}`;
    const queryPost = `
      INSERT INTO Posts (user_id, post_text, image_url, visibility)
      VALUES (?, ?, ?, ?)
    `;
    
    // First, insert the post into the Posts table
    db.query(queryPost, [userId, description, imageUrl, visibility], (err, result) => {
      if (err) {
        console.error('Database error while inserting post:', err);
        return res.status(500).json({ message: 'Failed to create post.' });
      }

      // Now, increment the contribution of the user
      const queryUpdateUser = `
        UPDATE Users
        SET contribution = contribution + 1
        WHERE id = ?
      `;
      
      db.query(queryUpdateUser, [userId], (errUpdate) => {
        if (errUpdate) {
          console.error('Database error while updating contribution:', errUpdate);
          return res.status(500).json({ message: 'Failed to update user contribution.' });
        }

        res.status(200).json({ message: 'Post created and contribution updated successfully!' });
      });
    });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});


// Profile backend******************************************************************
// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'profilePics')); // Save files in the folder
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const uploadpic = multer({ storage });

// Route to fetch user's profile information
app.get('/user-profile/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId || userId === 'null') {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  db.query('SELECT username, bio, profile_pic FROM Users WHERE id = ?', [userId], (err, results) => {
    if (err) {
      console.error('Error fetching user profile:', err);
      return res.status(500).json({ error: 'Error fetching user profile' });
    }

    if (results.length > 0) {
      res.json(results[0]); // Send the user's bio and profile picture filename
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });
});

// Route to fetch posts for a specific user
app.get('/user-posts/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId || userId === 'null') {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  // Query to get posts along with accurate like and dislike counts
  const query = `
    SELECT 
      post_id, 
      user_id, 
      image_url, 
      post_text, 
      created_at,
      CASE 
        WHEN liked_by IS NULL OR liked_by = '' THEN 0
        ELSE LENGTH(liked_by) - LENGTH(REPLACE(liked_by, ',', '')) + 1 
      END AS likes,
      CASE 
        WHEN disliked_by IS NULL OR disliked_by = '' THEN 0
        ELSE LENGTH(disliked_by) - LENGTH(REPLACE(disliked_by, ',', '')) + 1 
      END AS dislikes
    FROM Posts
    WHERE user_id = ?
    ORDER BY created_at DESC;
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching posts:', err);
      return res.status(500).json({ error: 'Error fetching posts' });
    }

    res.json(results); // Send the posts as a JSON response
  });
});


// New route for fetching comments for a specific post with profile pictures and reactions
app.get('/post/:postId/comments', (req, res) => {
  const postId = req.params.postId;

  if (!postId) {
    return res.status(400).json({ error: 'Invalid post ID' });
  }

  const query = `
    SELECT 
      c.comment_id, 
      c.comment_text, 
      c.created_at, 
      u.username, 
      u.profile_pic, 
      c.liked_by, 
      c.disliked_by
    FROM Comments c
    INNER JOIN Users u ON c.user_id = u.id
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC;
  `;

  db.query(query, [postId], (err, results) => {
    if (err) {
      console.error('Error fetching comments:', err);
      return res.status(500).json({ error: 'Error fetching comments' });
    }

    // Process the results to include likes and dislikes count
    const comments = results.map(comment => ({
      ...comment,
      likes: comment.liked_by ? comment.liked_by.split(',').length : 0,
      dislikes: comment.disliked_by ? comment.disliked_by.split(',').length : 0,
    }));

    res.json(comments); // Send the processed comments as a JSON response
  });
});




// Route to update profile
app.post('/update-profile', uploadpic.single('profilePic'), (req, res) => {
  const { bio, userId } = req.body; // Fetch userId from the request body
  const profilePic = req.file ? req.file.filename : null;

  if (!userId) {
    return res.status(400).json({ error: 'User ID is required' });
  }

  let query = 'UPDATE Users SET bio = ?';
  const params = [bio];

  if (profilePic) {
    query += ', profile_pic = ?';
    params.push(profilePic);
  }
  query += ' WHERE id = ?';
  params.push(userId);

  db.query(query, params, (err) => {
    if (err) {
      console.error('Error updating profile:', err);
      return res.status(500).json({ error: 'Error updating profile' });
    }

    db.query('SELECT bio, profile_pic FROM Users WHERE id = ?', [userId], (err, results) => {
      if (err) {
        console.error('Error fetching updated profile:', err);
        return res.status(500).json({ error: 'Error fetching updated profile' });
      }

      res.json({
        success: true,
        bio: results[0].bio,
        profilePic: results[0].profile_pic || 'default-pic.jpg',
      });
    });
  });
});

app.get('/user-posts-count/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId) {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  const query = 'SELECT COUNT(*) AS nbPosts FROM Posts WHERE user_id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching posts count:', err);
      return res.status(500).json({ error: 'Error fetching posts count' });
    }

    res.json(results[0]); // Return the count as nbPosts
  });
});

app.get('/user-friends-count/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId) {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  const query = 'SELECT COUNT(*) AS nbFriends FROM friends WHERE user_id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching friends count:', err);
      return res.status(500).json({ error: 'Error fetching friends count' });
    }

    res.json(results[0]); // Return the count as nbFriends
  });
});



// Feed backend*****************************************************

app.get('/feed', (req, res) => {
  const userId = req.query.userId;

  const query = `
      SELECT 
          Posts.post_id, Posts.post_text, Posts.image_url, Posts.created_at,
            Posts.liked_by, Posts.disliked_by,
          Users.username, Users.profile_pic
      FROM 
          Posts
      JOIN 
          Friends ON Posts.user_id = Friends.friend_id
      JOIN 
          Users ON Posts.user_id = Users.id
      WHERE 
          Friends.user_id = ? 
          AND Posts.visibility IN ('public', 'friends')
      ORDER BY 
          Posts.created_at DESC;
  `;

  db.query(query, [userId], (err, results) => {
      if (err) {
          console.error(err);
          res.status(500).send('Error fetching feed.');
      } else {
          res.json(results);
      }
  });
});


app.post('/post/:postId/reaction', (req, res) => {
  const { postId } = req.params;
  const { userId, reaction } = req.body;

  const fetchQuery = `SELECT liked_by, disliked_by FROM Posts WHERE post_id = ?`;
  db.query(fetchQuery, [postId], (err, results) => {
      if (err) {
          console.error(err);
          return res.status(500).send('Error fetching post data.');
      }

      const post = results[0];
      const likedBy = post.liked_by ? post.liked_by.split(',') : [];
      const dislikedBy = post.disliked_by ? post.disliked_by.split(',') : [];

      let updatedLikedBy = likedBy;
      let updatedDislikedBy = dislikedBy;

      let incrementActivity = false;

      if (reaction === 'like') {
          if (!likedBy.includes(userId)) {
              updatedLikedBy.push(userId);
              incrementActivity = !dislikedBy.includes(userId); // New reaction
          }
          updatedDislikedBy = dislikedBy.filter((id) => id !== userId);
      } else if (reaction === 'dislike') {
          if (!dislikedBy.includes(userId)) {
              updatedDislikedBy.push(userId);
              incrementActivity = !likedBy.includes(userId); // New reaction
          }
          updatedLikedBy = likedBy.filter((id) => id !== userId);
      }

      const updateQuery = `
          UPDATE Posts 
          SET liked_by = ?, disliked_by = ?
          WHERE post_id = ?
      `;
      db.query(
          updateQuery,
          [updatedLikedBy.join(','), updatedDislikedBy.join(','), postId],
          (err) => {
              if (err) {
                  console.error(err);
                  return res.status(500).send('Error updating reactions.');
              }

              if (incrementActivity) {
                  const activityQuery = `UPDATE Users SET activity = activity + 1 WHERE id = ?`;
                  db.query(activityQuery, [userId], (err) => {
                      if (err) console.error('Error updating activity:', err);
                  });
              }

              res.json({
                  likes: updatedLikedBy.length,
                  dislikes: updatedDislikedBy.length,
              });
          }
      );
  });
});


// Fetch comments for a post
app.get('/post/:postId/comments', (req, res) => {
  const { postId } = req.params;
  
  const query = `
      SELECT Comments.comment_id, Comments.comment_text, Comments.created_at, 
             Comments.liked_by, Comments.disliked_by, Users.username, Users.profile_pic
      FROM Comments
      JOIN Users ON Comments.user_id = Users.id
      WHERE Comments.post_id = ?
      ORDER BY Comments.created_at DESC;
  `;
  
  db.query(query, [postId], (err, results) => {
      if (err) {
          console.error(err);
          return res.status(500).send('Error fetching comments.');
      }
      res.json(results);
  });
});

// Add a comment to a post
app.post('/post/:postId/comment', (req, res) => {
  const { postId } = req.params;
  const { userId, commentText } = req.body;

  const insertQuery = `
      INSERT INTO Comments (post_id, user_id, comment_text, created_at)
      VALUES (?, ?, ?, NOW())
  `;

  db.query(insertQuery, [postId, userId, commentText], (err) => {
      if (err) {
          console.error(err);
          return res.status(500).send('Error adding comment.');
      }

      // Increment user's activity
      const activityQuery = `UPDATE Users SET activity = activity + 1 WHERE id = ?`;
      db.query(activityQuery, [userId], (err) => {
          if (err) console.error('Error updating activity:', err);
      });

      res.status(201).send('Comment added successfully.');
  });
});


// Like or Dislike a comment
app.post('/comment/:commentId/reaction', (req, res) => {
  const { commentId } = req.params;
  const { userId, reaction } = req.body;

  const fetchQuery = `SELECT liked_by, disliked_by FROM Comments WHERE comment_id = ?`;
  db.query(fetchQuery, [commentId], (err, results) => {
      if (err) {
          console.error(err);
          return res.status(500).send('Error fetching comment data.');
      }

      const comment = results[0];
      const likedBy = comment.liked_by ? comment.liked_by.split(',') : [];
      const dislikedBy = comment.disliked_by ? comment.disliked_by.split(',') : [];

      let updatedLikedBy = likedBy;
      let updatedDislikedBy = dislikedBy;

      if (reaction === 'like') {
          if (!likedBy.includes(userId)) {
              updatedLikedBy.push(userId);
          }
          updatedDislikedBy = dislikedBy.filter((id) => id !== userId);
      } else if (reaction === 'dislike') {
          if (!dislikedBy.includes(userId)) {
              updatedDislikedBy.push(userId);
          }
          updatedLikedBy = likedBy.filter((id) => id !== userId);
      }

      const updateQuery = `
          UPDATE Comments 
          SET liked_by = ?, disliked_by = ? 
          WHERE comment_id = ?
      `;
      db.query(
          updateQuery,
          [updatedLikedBy.join(','), updatedDislikedBy.join(','), commentId],
          (err) => {
              if (err) {
                  console.error(err);
                  return res.status(500).send('Error updating comment reactions.');
              }

              res.json({
                  likes: updatedLikedBy.length,
                  dislikes: updatedDislikedBy.length,
              });
          }
      );
  });
});

// top contributor
app.get('/top-contributor/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId) {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  const query = `
    SELECT u.username, u.profile_pic, u.contribution
    FROM friends f
    JOIN users u ON f.friend_id = u.id
    WHERE f.user_id = ?
    ORDER BY u.contribution DESC
    LIMIT 1;
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching top contributor:', err);
      return res.status(500).json({ error: 'Error fetching top contributor' });
    }

    if (results.length === 0 || results[0].contribution === 0) {
      return res.status(404).json({ message: 'None of your friends have contributed yet.' });
    }

    res.json(results[0]);
  });
});

//most active
app.get('/most-active/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId || isNaN(userId)) {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  const query = `
    SELECT u.username, u.profile_pic, u.activity
    FROM friends f
    JOIN users u ON f.friend_id = u.id
    WHERE f.user_id = ?
    ORDER BY u.activity DESC
    LIMIT 1;
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching most active friend:', err);
      return res.status(500).json({ error: 'Error fetching most active friend' });
    }

    // Handle no active friends or no results
    if (results.length === 0 || results[0].activity === 0) {
      return res.json({
        username: 'None of your friends have done any activity yet.',
        profile_pic: 'default-profile.jpg',
        activity: 0
      });
    }

    console.log('Most active friend:', results[0]);
    res.json(results[0]);
  });
});

// kamal*****************************************

app.get('/get-user-id', (req, res) => {
  const username = req.query.username;

  if (!username) {
      return res.status(400).json({ error: 'Username is required.' });
  }

  const query = `SELECT id FROM Users WHERE username = ?`;

  db.query(query, [username], (err, results) => {
      if (err) {
          console.error('Error fetching user ID:', err);
          return res.status(500).json({ error: 'Error fetching user ID.' });
      }

      if (results.length === 0) {
          return res.status(404).json({ error: 'User not found.' });
      }

      res.json({ userId: results[0].id });
  });
});


app.post('/send-message', (req, res) => {
  const { senderId, receiverId, message } = req.body;

  const query = `
      INSERT INTO messages (room, sender_id, message)
      VALUES (?, ?, ?)
  `;
  const room = `chat-${Math.min(senderId, receiverId)}-${Math.max(senderId, receiverId)}`;
  db.query(query, [room, senderId, message], (err) => {
      if (err) {
          console.error('Error inserting message:', err);
          return res.status(500).send('Failed to send message');
      }
      res.status(200).send('Message sent successfully');
  });
});

app.get('/user-posts-public/:userId', (req, res) => {
  const userId = req.params.userId;

  if (!userId || userId === 'null') {
    return res.status(400).json({ error: 'Invalid user ID' });
  }

  // Query to fetch only public posts
  const postQuery = `
    SELECT 
        post_id, 
        user_id, 
        image_url, 
        post_text, 
        created_at,
        visibility,
        CASE 
          WHEN liked_by IS NULL OR liked_by = '' THEN 0
          ELSE LENGTH(liked_by) - LENGTH(REPLACE(liked_by, ',', '')) + 1 
        END AS likes,
        CASE 
          WHEN disliked_by IS NULL OR disliked_by = '' THEN 0
          ELSE LENGTH(disliked_by) - LENGTH(REPLACE(disliked_by, ',', '')) + 1 
        END AS dislikes
    FROM Posts
    WHERE 
        user_id = ? 
        AND visibility = 'public'
    ORDER BY created_at DESC;
  `;

  db.query(postQuery, [userId], (err, posts) => {
    if (err) {
      console.error('Error fetching posts:', err);
      return res.status(500).json({ error: 'Error fetching posts' });
    }

    if (posts.length === 0) {
      return res.status(404).json({ error: 'No public posts found' });
    }

    res.json(posts);
  });
});



// Check friendship and fetch "friends" posts
app.get('/user-posts-friends/:viewerId/:profileId', (req, res) => {
  const { viewerId, profileId } = req.params;

  // Query to check friendship and fetch posts
  const query = `
      SELECT 
          post_id, 
          user_id, 
          image_url, 
          post_text, 
          created_at,
          visibility,
          CASE 
              WHEN liked_by IS NULL OR liked_by = '' THEN 0
              ELSE LENGTH(liked_by) - LENGTH(REPLACE(liked_by, ',', '')) + 1 
          END AS likes,
          CASE 
              WHEN disliked_by IS NULL OR disliked_by = '' THEN 0
              ELSE LENGTH(disliked_by) - LENGTH(REPLACE(disliked_by, ',', '')) + 1 
          END AS dislikes
      FROM Posts
      WHERE 
          user_id = ? 
          AND visibility IN ('public', 'friends') 
          AND (
              visibility = 'public' OR 
              EXISTS (
                  SELECT 1 
                  FROM friends 
                  WHERE 
                      (user_id = ? AND friend_id = ?) OR 
                      (user_id = ? AND friend_id = ?)
              )
          )
      ORDER BY created_at DESC;
  `;

  db.query(query, [profileId, profileId, viewerId, viewerId, profileId], (err, posts) => {
      if (err) {
          console.error('Error fetching posts:', err);
          return res.status(500).json({ error: 'Error fetching posts' });
      }

      res.json(posts);
  });
});










app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
